import cv2
import numpy as np
from tensorflow.python.keras.models import Sequential
from tensorflow.python.keras.layers import LSTM, Dense

# Define the number of classes (e.g., number of individuals)
num_classes = 10000

# Initialize the face data list
face_data = []
labels = []

# Initialize the face detection cascade

face_cascade = cv2.CascadeClassifier(r"/Users/raflyathalla/Downloads/Face detection/RNN-Face-Recognition/haarcascade_frontalface_default.xml")
# Initialize the webcam
cap = cv2.VideoCapture(0)

# Capture face images and preprocess them
while True:
    ret, frame = cap.read()

    # Convert the frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Perform face detection using the cascade classifier
    faces = face_cascade.detectMultiScale(
        gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30)
    )

    for x, y, w, h in faces:
        # Extract the face region from the grayscale image
        face = gray[y : y + h, x : x + w]

        # Preprocess the face image (e.g., resize, normalize, etc.)
        face = cv2.resize(face, (128, 128))
        face = face / 255.0

        # Add the preprocessed face image to the face data list
        face_data.append(face)

        # Add the label for the face image
        label = len(labels)
        labels.append(label)

        # Display the face region with label
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(
            frame,
            str(label),
            (x, y - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.9,
            (0, 255, 0),
            2,
        )

    # Display the frame
    cv2.imshow("Face Detection RNN", frame)

    # Break the loop if 'q' is pressed
    if cv2.waitKey(1) == ord("q"):
        break

# Release the webcam and close all windows
cap.release()
cv2.destroyAllWindows()

# Convert the face data and labels to numpy arrays
face_data = np.array(face_data)
labels = np.array(labels)

# Initialize the RNN model
model = Sequential()
model.add(LSTM(units=32, input_shape=(10, 128)))
model.add(Dense(units=num_classes, activation="softmax"))

# Compile the model
model.compile(
    loss="sparse_categorical_crossentropy", optimizer="adam", metrics=["accuracy"]
)

# Train the model on the face data
model.fit(face_data, labels, epochs=20)

# Save the trained model weights
model.save_weights("rnn_face_data_model_f.h5")
