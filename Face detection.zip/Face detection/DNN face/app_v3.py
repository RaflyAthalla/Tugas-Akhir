import streamlit as st
from streamlit_webrtc import webrtc_streamer, VideoTransformerBase
import cv2
import numpy as np
from sklearn.metrics import accuracy_score, f1_score, recall_score, precision_score


class DnnFaceDetection(VideoTransformerBase):
    def __init__(self):
        super().__init__()
        self.net = cv2.dnn.readNetFromCaffe(
            "deploy.prototxt", "res10_300x300_ssd_iter_140000.caffemodel"
        )

    def transform(self, frame):
        img = frame.to_ndarray(format="bgr24")

        blob = cv2.dnn.blobFromImage(
            cv2.resize(img, (300, 300)), 1.0, (300, 300), (104.0, 177.0, 123.0)
        )
        self.net.setInput(blob)
        detections = self.net.forward()
        self.detected_faces = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            if confidence > 0.5:
                box = detections[0, 0, i, 3:7] * np.array(
                    [img.shape[1], img.shape[0], img.shape[1], img.shape[0]]
                )
                (startX, startY, endX, endY) = box.astype("int")

                self.detected_faces.append((startX, startY, endX, endY))

                cv2.rectangle(img, (startX, startY), (endX, endY), (0, 255, 0), 2)
                label = f"Face {i+1}"
                cv2.putText(
                    img,
                    label,
                    (startX, startY - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (0, 255, 0),
                    2,
                )

        detected_labels = np.ones(len(self.detected_faces))
        accuracy = accuracy_score(np.ones(1), detected_labels)
        f1 = f1_score(np.ones(1), detected_labels)
        recall = recall_score(np.ones(1), detected_labels)
        precision = precision_score(np.ones(1), detected_labels)

        print("Akurasi :", accuracy)
        print("f1_score :", f1)
        print("recall :", recall)
        print("precision :", precision)
        print("---------------------------------")

        return img


def main():
    st.title("DNN Webcam Face Detection")
    webrtc_ctx = webrtc_streamer(
        key="example", video_transformer_factory=DnnFaceDetection, async_transform=True
    )


if __name__ == "__main__":
    main()
